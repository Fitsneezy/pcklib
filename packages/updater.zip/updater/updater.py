import os
import zipfile
import requests
import shutil
import sys

REPO_URL = 'https://github.com/yourusername/pcklib/raw/main/packages/'
INSTALL_DIR = 'installed_packages'
UPDATE_PACKAGE = 'updater.zip'  # Name of the update package

def download_file(url, local_filename):
    print(f"Downloading from {url}")
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()  # Check for HTTP errors
        with open(local_filename, 'wb') as file:
            shutil.copyfileobj(response.raw, file)
        print(f"Downloaded file: {local_filename}")
    except requests.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
        sys.exit(1)
    except Exception as err:
        print(f"Other error occurred: {err}")
        sys.exit(1)

def install_update(zip_path):
    if not os.path.exists(zip_path):
        print(f"Update package file '{zip_path}' not found. Downloading...")
        download_file(f"{REPO_URL}{zip_path}", zip_path)
    
    if not os.path.exists(INSTALL_DIR):
        os.makedirs(INSTALL_DIR)
    
    extract_dir = os.path.join(INSTALL_DIR, 'update')
    if os.path.exists(extract_dir):
        print(f"Update already installed. Removing old version.")
        shutil.rmtree(extract_dir)
    
    print(f"Installing update from '{zip_path}'")
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        print(f"Update installed successfully.")
    except zipfile.BadZipFile:
        print(f"Error: '{zip_path}' is not a valid ZIP file.")
        sys.exit(1)
    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(1)

def main():
    print("Starting ByteVault updater...")
    install_update(UPDATE_PACKAGE)
    print("Update complete. Please restart ByteVault to apply changes.")

if __name__ == "__main__":
    main()
