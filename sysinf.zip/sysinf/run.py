import platform
import sys
import os

def collect_system_info():
    # Get system details
    system_info = {
        "Platform": platform.system(),
        "Platform Version": platform.version(),
        "Python Version": sys.version,
        "Architecture": platform.architecture(),
        "Machine": platform.machine(),
        "Processor": platform.processor(),
    }

    # Create the info.txt file
    with open("info.txt", "w") as file:
        file.write("System Information:\n")
        for key, value in system_info.items():
            file.write(f"{key}: {value}\n")
    
    print("System information saved to 'info.txt'.")
    
if __name__ == "__main__":
    collect_system_info()
